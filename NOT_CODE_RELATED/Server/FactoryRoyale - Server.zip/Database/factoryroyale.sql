-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Jan 20, 2020 at 11:47 PM
-- Server version: 5.7.24
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `factoryroyale`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `player_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `company_money` int(11) NOT NULL DEFAULT '0',
  `company_worker_amount` int(11) DEFAULT '10',
  `company_amount_of_factories_owned` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`player_id`, `company_id`, `company_money`, `company_worker_amount`, `company_amount_of_factories_owned`) VALUES
(1, 1, 200, 10, 1),
(1, 2, 200, 10, 1),
(1, 3, 200, 10, 1),
(1, 4, 200, 10, 1),
(1, 5, 200, 10, 1),
(1, 6, 200, 10, 1),
(1, 7, 200, 10, 1),
(1, 8, 200, 10, 1),
(1, 9, 200, 10, 1),
(1, 10, 200, 10, 1),
(1, 11, 200, 10, 1),
(1, 12, 200, 10, 1),
(1, 13, 200, 10, 1),
(1, 14, 200, 10, 1),
(1, 15, 200, 10, 1),
(1, 16, 200, 10, 1),
(1, 17, 200, 10, 1),
(1, 18, 200, 10, 1),
(1, 19, 200, 10, 1),
(1, 20, 200, 10, 1),
(1, 21, 200, 10, 1),
(1, 22, 200, 10, 1),
(1, 23, 200, 10, 1),
(2, 1, 1000, 10, 1),
(2, 2, 1000, 10, 1),
(2, 3, 1000, 10, 1),
(2, 4, 1000, 10, 1),
(2, 5, 1000, 10, 1),
(2, 6, 1000, 10, 1),
(2, 7, 1000, 10, 1),
(2, 8, 1000, 10, 1),
(2, 9, 1000, 10, 1),
(2, 10, 1000, 10, 1),
(2, 11, 1000, 10, 1),
(2, 12, 1000, 10, 1),
(2, 13, 1000, 10, 1),
(2, 14, 1000, 10, 1),
(2, 15, 1000, 10, 1),
(2, 16, 1000, 10, 1),
(2, 17, 1000, 10, 1),
(2, 18, 1000, 10, 1),
(2, 19, 1000, 10, 1),
(2, 20, 1000, 10, 1),
(2, 21, 1000, 10, 1),
(2, 22, 1000, 10, 1),
(2, 23, 1000, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `factories`
--

CREATE TABLE `factories` (
  `player_id` int(11) NOT NULL,
  `factory_id` int(11) NOT NULL,
  `factory_name` varchar(100) NOT NULL,
  `factory_owner_id` int(11) NOT NULL,
  `factory_worker_amount` int(11) NOT NULL DEFAULT '10',
  `factory_money_per_second` int(11) NOT NULL DEFAULT '100',
  `factory_security_level` int(11) NOT NULL DEFAULT '1',
  `factory_efficiency_level` int(11) NOT NULL DEFAULT '1',
  `factory_worker_conditions_level` int(11) NOT NULL DEFAULT '1',
  `factory_worker_happiness` int(11) NOT NULL DEFAULT '50',
  `factory_house_amount` int(11) NOT NULL DEFAULT '1',
  `factory_buy_price` int(11) NOT NULL DEFAULT '5000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `factories`
--

INSERT INTO `factories` (`player_id`, `factory_id`, `factory_name`, `factory_owner_id`, `factory_worker_amount`, `factory_money_per_second`, `factory_security_level`, `factory_efficiency_level`, `factory_worker_conditions_level`, `factory_worker_happiness`, `factory_house_amount`, `factory_buy_price`) VALUES
(1, 1, 'Wroclaw', 1, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 2, 'Glogow', 2, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 3, 'Sciniawa', 3, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 4, 'Milicz', 4, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 5, 'Brzeg', 5, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 6, 'Namyslow', 6, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 7, 'Opole', 7, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 8, 'Henrykóv', 8, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 9, 'Kozle', 9, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 10, 'Niza', 10, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 11, 'Klodzko', 11, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 12, 'Rachibórz', 12, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 13, 'Bytom', 13, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 14, 'Ujazd', 14, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 15, 'Cieszyn', 15, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 16, 'Oswiecim', 16, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 17, 'Niemcza', 17, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 18, 'Swidnica', 18, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 19, 'Legnica', 19, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 20, 'Lwówek', 20, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 21, 'Boleslawiec', 21, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 22, 'Krozno', 22, 10, 100, 1, 1, 1, 50, 1, 5000),
(1, 23, 'Zagañ', 23, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 24, 'Wroclaw', 1, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 25, 'Glogow', 2, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 26, 'Sciniawa', 3, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 27, 'Milicz', 4, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 28, 'Brzeg', 5, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 29, 'Namyslow', 6, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 30, 'Opole', 7, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 31, 'Henrykóv', 8, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 32, 'Kozle', 9, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 33, 'Niza', 10, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 34, 'Klodzko', 11, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 35, 'Rachibórz', 12, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 36, 'Bytom', 13, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 37, 'Ujazd', 14, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 38, 'Cieszyn', 15, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 39, 'Oswiecim', 16, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 40, 'Niemcza', 17, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 41, 'Swidnica', 18, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 42, 'Legnica', 19, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 43, 'Lwówek', 20, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 44, 'Boleslawiec', 21, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 45, 'Krozno', 22, 10, 100, 1, 1, 1, 50, 1, 5000),
(2, 46, 'Zagañ', 23, 10, 100, 1, 1, 1, 50, 1, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `playerconnection`
--

CREATE TABLE `playerconnection` (
  `player_code` int(11) NOT NULL,
  `player_company_name` varchar(100) NOT NULL DEFAULT 'playerComp'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `playerconnection`
--

INSERT INTO `playerconnection` (`player_code`, `player_company_name`) VALUES
(1, 'player 1 Comp'),
(2, 'player 2 Comp');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `player_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL DEFAULT '1',
  `bot_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`player_id`, `company_id`, `bot_id`) VALUES
(1, 1, 0),
(1, 2, 1),
(1, 3, 2),
(1, 4, 3),
(1, 5, 4),
(1, 6, 5),
(1, 7, 6),
(1, 8, 7),
(1, 9, 8),
(1, 10, 9),
(1, 11, 10),
(1, 12, 11),
(1, 13, 12),
(1, 14, 13),
(1, 15, 14),
(1, 16, 15),
(1, 17, 16),
(1, 18, 17),
(1, 19, 18),
(1, 20, 19),
(1, 21, 20),
(1, 22, 21),
(1, 23, 22),
(2, 1, 0),
(2, 2, 1),
(2, 3, 2),
(2, 4, 3),
(2, 5, 4),
(2, 6, 5),
(2, 7, 6),
(2, 8, 7),
(2, 9, 8),
(2, 10, 9),
(2, 11, 10),
(2, 12, 11),
(2, 13, 12),
(2, 14, 13),
(2, 15, 14),
(2, 16, 15),
(2, 17, 16),
(2, 18, 17),
(2, 19, 18),
(2, 20, 19),
(2, 21, 20),
(2, 22, 21),
(2, 23, 22);

-- --------------------------------------------------------

--
-- Table structure for table `sabotage`
--

CREATE TABLE `sabotage` (
  `sabotager_id` int(11) NOT NULL,
  `sabotaged_efficiency` tinyint(1) NOT NULL DEFAULT '0',
  `sabotaged_workers` tinyint(1) NOT NULL DEFAULT '0',
  `sabotaged_workers_and_efficiency` tinyint(1) NOT NULL DEFAULT '0',
  `sabotaged_factory` int(11) NOT NULL,
  `sabotaged_company` int(11) NOT NULL,
  `sabotage_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `upgrade_costs`
--

CREATE TABLE `upgrade_costs` (
  `eff_lvl1` int(11) NOT NULL DEFAULT '0',
  `eff_lvl2` int(11) NOT NULL DEFAULT '500',
  `eff_lvl3` int(11) NOT NULL DEFAULT '1000',
  `eff_lvl4` int(11) NOT NULL DEFAULT '2000',
  `eff_lvl5` int(11) DEFAULT '3000',
  `sec_lvl1` int(11) NOT NULL DEFAULT '0',
  `sec_lvl2` int(11) NOT NULL DEFAULT '1000',
  `sec_lvl3` int(11) NOT NULL DEFAULT '2000',
  `sec_lvl4` int(11) NOT NULL DEFAULT '4000',
  `sec_lvl5` int(11) NOT NULL DEFAULT '8000',
  `wCond_lvl1` int(11) NOT NULL DEFAULT '0',
  `wCond_lvl2` int(11) NOT NULL DEFAULT '300',
  `wCond_lvl3` int(11) NOT NULL DEFAULT '1000',
  `wCond_lvl4` int(11) NOT NULL DEFAULT '1500',
  `wCond_lvl5` int(11) NOT NULL DEFAULT '2000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `upgrade_costs`
--

INSERT INTO `upgrade_costs` (`eff_lvl1`, `eff_lvl2`, `eff_lvl3`, `eff_lvl4`, `eff_lvl5`, `sec_lvl1`, `sec_lvl2`, `sec_lvl3`, `sec_lvl4`, `sec_lvl5`, `wCond_lvl1`, `wCond_lvl2`, `wCond_lvl3`, `wCond_lvl4`, `wCond_lvl5`) VALUES
(0, 500, 1000, 2000, 3000, 0, 1000, 2000, 4000, 8000, 0, 300, 1000, 1500, 2000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD KEY `company_id` (`company_id`) USING BTREE;

--
-- Indexes for table `factories`
--
ALTER TABLE `factories`
  ADD PRIMARY KEY (`factory_id`),
  ADD KEY `factory_owner_id_2` (`factory_owner_id`);

--
-- Indexes for table `playerconnection`
--
ALTER TABLE `playerconnection`
  ADD PRIMARY KEY (`player_code`) USING BTREE;

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD KEY `company_id` (`company_id`),
  ADD KEY `player_id` (`player_id`) USING BTREE;

--
-- Indexes for table `sabotage`
--
ALTER TABLE `sabotage`
  ADD PRIMARY KEY (`sabotager_id`),
  ADD UNIQUE KEY `sabotaged_company` (`sabotaged_company`),
  ADD UNIQUE KEY `sabotaged_factory` (`sabotaged_factory`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `factories`
--
ALTER TABLE `factories`
  MODIFY `factory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `playerconnection`
--
ALTER TABLE `playerconnection`
  MODIFY `player_code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `player_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `factories`
--
ALTER TABLE `factories`
  ADD CONSTRAINT `factoryOwner_fk_company` FOREIGN KEY (`factory_owner_id`) REFERENCES `companies` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `players`
--
ALTER TABLE `players`
  ADD CONSTRAINT `players_fk_playerconnection` FOREIGN KEY (`player_id`) REFERENCES `playerconnection` (`player_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `players_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`);

--
-- Constraints for table `sabotage`
--
ALTER TABLE `sabotage`
  ADD CONSTRAINT `sabotage_fk_company` FOREIGN KEY (`sabotager_id`) REFERENCES `companies` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sabotage_fk_factory` FOREIGN KEY (`sabotaged_factory`) REFERENCES `factories` (`factory_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `sabotaged_fk_company` FOREIGN KEY (`sabotaged_company`) REFERENCES `companies` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
