<?php

include "Server.php";

$wCondlvl = array();

$selectedFac = $_POST["selected_factory"];
$playerCode = $_POST["player_code"];
$wCondLvlCost = $_POST["Wcond_level_cost"];

$sql = "SELECT factory_worker_conditions_level FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $sql2 = "UPDATE companies SET company_money = company_money - '" . $wCondLvlCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
        $result2 = $link->query($sql2);

        $wCondlvl = $row["factory_worker_conditions_level"];
    }
}
else
{
    echo "Something went wrong with: " . $wCondlvl;
}

echo json_encode($wCondlvl);

$link->close();

?>