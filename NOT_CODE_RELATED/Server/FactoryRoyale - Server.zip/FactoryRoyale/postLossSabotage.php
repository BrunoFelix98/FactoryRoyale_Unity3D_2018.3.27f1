<?php

include "Server.php";

$sabotages = array();

$sabotagerComp = $_POST["sabotager_company_id"];
$selectedFac = $_POST["selected_factory"];
$sabotagedComp = $_POST["sabotaged_company_id"];
$playerCode = $_POST["player_code"];

$sql = "UPDATE factories SET factory_worker_amount = factory_worker_amount - 5, factory_money_per_second = factory_money_per_second - 25 WHERE factory_id = '" . $sabotagerComp . "' and player_id = '" . $playerCode . "';";

if($result = $link->query($sql))
{
    echo "Factory sabotage loss";
}
else
{
    echo "Something went wrong" . $link->error;
}

echo json_encode($sabotages);

$link->close();

?>