<?php

include "Server.php";

$Names = array();

if(isset($_GET["factory_owner_id"], $_GET["player_id"]))
{
    $ownerID = $_GET["factory_owner_id"];
    $playerCode = $_GET["player_id"];
}
else
{
    $ownerID = -1;
    $playerCode = -1;
}

if($ownerID > 0)
{
    $idResult = mysqli_query($link, "SELECT factory_name FROM factories WHERE factory_owner_id = $ownerID and player_id = $playerCode;");

    while($row = mysqli_fetch_assoc($idResult))
    {
        $Names[]=$row;
    }

    mysqli_close($link);
}

echo '{"Names":' . json_encode($Names) . "}";

?>