<?php

include "Server.php";

$seclvl = array();

$selectedFac = $_POST["selected_factory"];
$playerCode = $_POST["player_code"];
$secLvlCost = $_POST["sec_level_cost"];

$sql = "SELECT factory_security_level FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $sql2 = "UPDATE companies SET company_money = company_money - '" . $secLvlCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
        $result2 = $link->query($sql2);

        $seclvl = $row["factory_security_level"];
    }
}
else
{
    echo "Something went wrong with: " . $seclvl;
}

echo json_encode($seclvl);

$link->close();

?>