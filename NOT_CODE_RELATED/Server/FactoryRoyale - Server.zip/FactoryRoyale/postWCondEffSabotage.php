<?php

include "Server.php";

$sabotages = array();

$sabotagerComp = $_POST["sabotager_company_id"];
$selectedFac = $_POST["selected_factory"];
$sabotagedComp = $_POST["sabotaged_company_id"];

$sql = "INSERT INTO sabotage (sabotager_id, sabotaged_workers_and_efficiency, sabotaged_factory, sabotaged_company, sabotage_timestamp) VALUES ('" . $sabotagerComp . "', true, '" . $selectedFac . "', '" . $sabotagedComp . "', CURRENT_TIME());";

$result = $link->query($sql);

echo json_encode($sabotages);

$link->close();

?>