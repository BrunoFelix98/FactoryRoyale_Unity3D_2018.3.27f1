<?php

include "Server.php";

$money = array();

$playerCode = $_POST["player_code"];
$selectedComp = $_POST["selected_comp"];

$sql = "SELECT company_money FROM companies WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $money = $row["company_money"];
    }
}
else
{
    echo "Something went wrong with: " . $money;
}

echo json_encode($money);

$link->close();

?>