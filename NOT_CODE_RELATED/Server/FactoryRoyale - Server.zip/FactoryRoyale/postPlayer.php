<?php

include "Server.php";

$player = array();

$fNames = array("Wroclaw", "Glogow", "Sciniawa", "Milicz", "Brzeg", "Namyslow", "Opole", "Henrykóv", "Kozle", "Niza", "Klodzko", "Rachibórz", "Bytom", "Ujazd", "Ciezyn", "Oswiecim", "Niemcza", "Swidnica", "Legnica", "Lwówek", "Boleslawiec", "Krozno", "Zagañ");

$playerCode = $_POST["player_code"];

$sql = "SELECT factories.* FROM factories JOIN players ON factories.player_id = players.player_id AND factories.factory_owner_id = players.company_id WHERE players.player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{
    echo json_encode($player);
}
else
{
    echo "Player: " . $player . " Player code: " . $playerCode;

    $sql2 = "INSERT INTO playerconnection (player_code) VALUES ('". $playerCode ."');";

    for($i = 0; $i <= 22; $i++)
    {
        $sql3 = "INSERT INTO players (player_id, company_id, bot_id) VALUES ('" . $playerCode . "', '" . $i . "' + 1,'" . $i . "');";
        $sql4 = "INSERT INTO factories (player_id, factory_name, factory_owner_id) VALUES ('" . $playerCode . "', '" . $fNames[$i] . "', '" . $i ."' + 1);";
    }

    if($link->query($sql2) === TRUE)
    {
        echo "New user";
    }
    else
    {
        echo "Player couldnt be added: " . $sql2 . $link->error . $player;
    }

    if($link->query($sql3) === TRUE)
    {
        echo "New bots with user";
    }
    else
    {
        echo "Player & bots couldnt be added: " . $sql3 . $link->error . $playerCode . $i;
    }
}

$link->close();

?>