<?php

include "Server.php";

$efflvl = array();

$selectedFac = $_POST["selected_factory"];
$playerCode = $_POST["player_code"];

$sql = "SELECT factory_efficiency_level FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
$result = $link->query($sql);

$sql2 = "SELECT company_money FROM companies WHERE company_id = 1 and player_id = '" . $playerCode . "';";
$result2 = $link->query($sql2);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        if($row["factory_efficiency_level"] >= 1 && $row["factory_efficiency_level"] <= 5)
        {
            $effCost = 500;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $effCost)
                    {
                        $sql3 = "UPDATE factories SET factory_efficiency_level = factory_efficiency_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $effCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second + 30, factory_worker_happiness = factory_worker_happiness - 20 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 2 of Efficiency for your factory, your factory efficiency level is now: " . $row["factory_efficiency_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 1";
            } 
        }
        if($row["factory_efficiency_level"] >= 2 && $row["factory_efficiency_level"] <= 5)
        {
            $effCost = 1000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $effCost)
                    {
                        $sql3 = "UPDATE factories SET factory_efficiency_level = factory_efficiency_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $effCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second + 40, factory_worker_happiness = factory_worker_happiness - 30 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 3 of Efficiency for your factory, your factory efficiency level is now: " . $row["factory_efficiency_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 2";
            } 
        }
        if($row["factory_efficiency_level"] >= 3 && $row["factory_efficiency_level"] <= 5)
        {
            $effCost = 2000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $effCost)
                    {
                        $sql3 = "UPDATE factories SET factory_efficiency_level = factory_efficiency_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $effCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second + 50, factory_worker_happiness = factory_worker_happiness - 35 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 4 of Efficiency for your factory, your factory efficiency level is now: " . $row["factory_efficiency_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 3";
            } 
        }
        if($row["factory_efficiency_level"] >= 4 && $row["factory_efficiency_level"] <= 5)
        {
            $effCost = 3000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $effCost)
                    {
                        $sql3 = "UPDATE factories SET factory_efficiency_level = factory_efficiency_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $effCost . "' WHERE company_id = 1 and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second + 60, factory_worker_happiness = factory_worker_happiness - 40 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 5 of Efficiency for your factory, your factory efficiency level is now: " . $row["factory_efficiency_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 4";
            } 
        }
        if($row["factory_efficiency_level"] = 5)
        {
            echo "Max level";
        }
    }
}
else
{
    echo "This has no price" . $row;
}

echo json_encode($efflvl);

$link->close();

?>