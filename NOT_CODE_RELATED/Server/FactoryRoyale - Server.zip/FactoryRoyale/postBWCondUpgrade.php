<?php

include "Server.php";

$wCondLvl = array();

$selectedFac = $_POST["selected_factory"];
$playerCode = $_POST["player_code"];
$selectedComp = $_POST["company_selected"];

$sql = "SELECT factory_worker_conditions_level FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
$result = $link->query($sql);

$sql2 = "SELECT company_money FROM companies WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
$result2 = $link->query($sql2);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        if($row["factory_worker_conditions_level"] >= 1 && $row["factory_worker_conditions_level"] <= 5)
        {
            $wCondCost = 300;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $wCondCost)
                    {
                        $sql3 = "UPDATE factories SET factory_worker_conditions_level = factory_worker_conditions_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $wCondCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second - 20, factory_worker_happiness = factory_worker_happiness + 15 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 2 of Worker conditions for your factory, your factory worker conditions level is now: " . $row["factory_worker_conditions_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 1";
            } 
        }
        if($row["factory_worker_conditions_level"] >= 2 && $row["factory_worker_conditions_level"] <= 5)
        {
            $wCondCost = 1000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $wCondCost)
                    {
                        $sql3 = "UPDATE factories SET factory_worker_conditions_level = factory_worker_conditions_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $wCondCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second - 25, factory_worker_happiness = factory_worker_happiness + 20 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 3 of Worker conditions for your factory, your factory worker conditions level is now: " . $row["factory_worker_conditions_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 2";
            } 
        }
        if($row["factory_worker_conditions_level"] >= 3 && $row["factory_worker_conditions_level"] <= 5)
        {
            $wCondCost = 1500;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $wCondCost)
                    {
                        $sql3 = "UPDATE factories SET factory_worker_conditions_level = factory_worker_conditions_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $wCondCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second - 30, factory_worker_happiness = factory_worker_happiness + 25 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 4 of Worker conditions for your factory, your factory worker conditions level is now: " . $row["factory_worker_conditions_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 3";
            } 
        }
        if($row["factory_worker_conditions_level"] >= 4 && $row["factory_worker_conditions_level"] <= 5)
        {
            $wCondCost = 2000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $wCondCost)
                    {
                        $sql3 = "UPDATE factories SET factory_worker_conditions_level = factory_worker_conditions_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $wCondCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_money_per_second = factory_money_per_second - 35, factory_worker_happiness = factory_worker_happiness + 30 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 5 of Worker conditions for your factory, your factory worker conditions level is now: " . $row["factory_security_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 4";
            } 
        }
        if($row["factory_worker_conditions_level"] = 5)
        {
            echo "Max level";
        }
    }
}
else
{
    echo "This has no price" . $row;
}

echo json_encode($wCondLvl);

$link->close();

?>