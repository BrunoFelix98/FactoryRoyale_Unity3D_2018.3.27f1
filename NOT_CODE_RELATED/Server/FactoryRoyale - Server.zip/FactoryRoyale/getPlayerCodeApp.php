<?php

include "Server.php";

$playerCode = $_GET["player_code"];

$sql = "SELECT player_company_name FROM playerconnection WHERE player_code = '" . $playerCode . "';";
$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        echo $row["player_company_name"];
    }
}
else
{
    echo "Player nonexistent: " . $playerCode;
}

$link->close();

?>