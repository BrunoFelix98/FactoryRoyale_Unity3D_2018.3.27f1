<?php

include "Server.php";

$players = array();

$sql = "SELECT * FROM playerconnection;";

$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $players[] = $row;
    }
}
else
{
    echo "Something went wrong with: " . $players;
}

echo json_encode($players);

$link->close();

?>