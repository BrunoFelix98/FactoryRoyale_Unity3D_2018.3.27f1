<?php

include "Server.php";

$secLvl = array();

$selectedFac = $_POST["selected_factory"];
$playerCode = $_POST["player_code"];
$selectedComp = $_POST["company_selected"];

$sql = "SELECT factory_security_level FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
$result = $link->query($sql);

$sql2 = "SELECT company_money FROM companies WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
$result2 = $link->query($sql2);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        if($row["factory_security_level"] >= 1 && $row["factory_security_level"] <= 5)
        {
            $secCost = 1000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $secCost)
                    {
                        $sql3 = "UPDATE factories SET factory_security_level = factory_security_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $secCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_worker_happiness = factory_worker_happiness + 5 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 2 of Security for your factory, your factory security level is now: " . $row["factory_security_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 1";
            } 
        }
        if($row["factory_security_level"] >= 2 && $row["factory_security_level"] <= 5)
        {
            $secCost = 2000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $secCost)
                    {
                        $sql3 = "UPDATE factories SET factory_security_level = factory_security_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $secCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_worker_happiness = factory_worker_happiness + 10 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 3 of Security for your factory, your factory security level is now: " . $row["factory_security_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 2";
            } 
        }
        if($row["factory_security_level"] >= 3 && $row["factory_security_level"] <= 5)
        {
            $secCost = 4000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $secCost)
                    {
                        $sql3 = "UPDATE factories SET factory_security_level = factory_security_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $secCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_worker_happiness = factory_worker_happiness + 15 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 4 of Security for your factory, your factory security level is now: " . $row["factory_security_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 3";
            } 
        }
        if($row["factory_security_level"] >= 4 && $row["factory_security_level"] <= 5)
        {
            $secCost = 8000;

            if($result2->num_rows > 0)
            {
                while($row2 = $result2->fetch_assoc())
                {
                    if($row2["company_money"] >= $secCost)
                    {
                        $sql3 = "UPDATE factories SET factory_security_level = factory_security_level + 1 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result3 = $link->query($sql3);

                        $sql4 = "UPDATE companies SET company_money = company_money - '" . $secCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
                        $result4 = $link->query($sql4);

                        $sql5 = "UPDATE factories SET factory_worker_happiness = factory_worker_happiness + 20 WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
                        $result5 = $link->query($sql5);

                        echo "You have purchased level 5 of Security for your factory, your factory security level is now: " . $row["factory_security_level"] . " and your money is now: " . $row2["company_money"];

                    }
                    else
                    {
                        echo "You dont have enough money";
                    }
                }
            }
            else
            {
                echo "You are not at level 4";
            } 
        }
        if($row["factory_security_level"] = 5)
        {
            echo "Max level";
        }
    }
}
else
{
    echo "This has no price" . $row;
}

echo json_encode($secLvl);

$link->close();

?>