<?php

$user = 'oofer';
$password = 'oofer';
$db = 'factoryroyale';
$host = 'localhost';
$port = 3307;

$link = mysqli_init();
$success = mysqli_real_connect(
   $link, 
   $host, 
   $user, 
   $password, 
   $db,
   $port
);

?>