<?php

include "Server.php";

$companyMoney = array();

$moneyAmount = $_POST["amount_of_money"];
$playerCode = $_POST["player_code"];

$sql = "SELECT company_money FROM companies WHERE player_id = '" . $playerCode . "';";
$result = $link->query($sql);

if($result->num_rows > 0)
{
    $sql3 = "UPDATE companies SET company_money = '" . $moneyAmount . "' WHERE player_id = '" . $playerCode . "';";
    $result3 = $link->query($sql3);
}
else
{
    echo "No player" . $moneyAmount;
}

echo json_encode($companyMoney);

$link->close();

?>