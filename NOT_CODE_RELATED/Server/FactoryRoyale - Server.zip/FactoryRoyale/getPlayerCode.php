<?php

include "Server.php";

$player = array();

$playerCode = $_GET["player_code"];

$sql = "SELECT * FROM playerconnection;";

$result = $link->query($sql);

if($result->num_rows > 0)
{

    while($row = $result->fetch_assoc())
    {
        $playerCode = $row["player_code"];

        $player[] = $row;
    }
}
else
{
    echo "Something went wrong with: " . $player;
}

echo json_encode($player);

$link->close();

?>