<?php

include "Server.php";

$factory = array();

$playerCode = $_POST["player_code"];

$factoryID = $_GET["factory_id"];
$factoryName = $_GET["factory_name"];
$factoryOwnerID = $_GET["factory_owner_id"];
$factoryMoneyPs = $_GET["factory_money_per_second"];
$factoryWorkerAmount = $_GET["factory_worker_amount"];
$factoryEffLvl = $_GET["factory_efficiency_level"];
$factorySecLvl = $_GET["factory_security_level"];
$factoryWCondLvl = $_GET["factory_worker_conditions_level"];
$factoryWHappiness = $_GET["factory_worker_happiness"];
$factoryHouseAmount = $_GET["factory_house_amount"];
$factoryBuyPrice = $_GET["factory_buy_price"];

$sql = "SELECT * FROM factories WHERE player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{

    while($row = $result->fetch_assoc())
    {
        $factory[] = $row;
    }
}
else
{
    echo "Something went wrong with: " . $factory . " and with the code: " . $playerCode;
}

echo json_encode($factory);

$link->close();

?>