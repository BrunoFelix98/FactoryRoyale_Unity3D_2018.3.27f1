<?php

include "Server.php";

$Factory = array();

if(isset($_GET["factory_owner_id"], $_GET["player_id"]))
{
    $ownerID = $_GET["factory_owner_id"];
    $playerCode = $_GET["player_id"];
}
else
{
    $ownerID = -1;
    $playerCode = -1;
}

if($ownerID > 0)
{
    $idResult = mysqli_query($link, "SELECT factory_name, factory_worker_amount, factory_money_per_second, factory_efficiency_level, factory_security_level, factory_worker_conditions_level, factory_worker_happiness FROM factories WHERE factory_owner_id = $ownerID and player_id = $playerCode;");

    while($row = mysqli_fetch_assoc($idResult))
    {
        $Factory[]=$row;
    }

    mysqli_close($link);
}

echo '{"Factory":' . json_encode($Factory) . "}";

?>