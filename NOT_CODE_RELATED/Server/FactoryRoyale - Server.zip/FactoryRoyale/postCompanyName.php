<?php

include "Server.php";

$names = array();

$playerCompName = $_POST["player_company_name"];
$playerCode = $_POST["player_code"];

$sql = "SELECT * FROM playerconnection WHERE player_code = '" . $playerCode . "';";
$result = $link->query($sql);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $sql2 = "UPDATE playerconnection SET player_company_name = player_company_name - '" . $playerCompName . "' WHERE player_code = '" . $playerCode . "';";
        $result2 = $link->query($sql2);
        
        echo "Error updating record: " . $link->error;
    }
}
else
{
    echo "Something went wrong" . $link->error;
}

$link->close();

?>