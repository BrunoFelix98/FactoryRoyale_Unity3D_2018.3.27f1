<?php

include "Server.php";

$facCostMoney = array();

$selectedFac = $_POST["selected_factory"];
$selectedFacOwner = $_POST["selected_factory_owner"];
$playerCode = $_POST["player_code"];
$selectedComp = $_POST["company_selected"];

$sql = "SELECT factory_buy_price FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
$result = $link->query($sql);

$sql2 = "SELECT company_money FROM companies WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";
$result2 = $link->query($sql2);

$sql3 = "SELECT factory_worker_amount FROM factories WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";
$result3 = $link->query($sql3);

if($result->num_rows > 0)
{
    while($row = $result->fetch_assoc())
    {
        $facCost = 10000;

        if($result2->num_rows > 0)
        {
            while($row2 = $result2->fetch_assoc())
            {
                if($row2["company_money"] >= $facCost)
                {
                    $sql4 = "UPDATE companies SET company_money = company_money - '" . $facCost . "' WHERE company_id = '" . $selectedComp . "' and player_id = '" . $playerCode . "';";

                    if($result4 = $link->query($sql4))
                    {
                        echo "Successfully updated company money";
                    }
                    else
                    {
                        echo "Company money not updated" . $link->error;
                    }

                    $sql5 = "UPDATE factories SET factory_owner_id = '" . $selectedComp . "' WHERE factory_id = '" . $selectedFac . "' and player_id = '" . $playerCode . "';";

                    if($result5 = $link->query($sql5))
                    {
                        echo "Successfully updated factory owner";
                    }
                    else
                    {
                        echo "Factory owner not updated" . $link->error;
                    }

                    $sql6 = "UPDATE companies SET company_amount_of_factories_owned = company_amount_of_factories_owned - 1 WHERE company_id = '" . $selectedFacOwner . "' and player_id = '" . $playerCode . "';";

                    if($result6 = $link->query($sql6))
                    {
                        echo "Successfully updated amount of factories owned";
                    }
                    else
                    {
                        echo "Amount of factories owned not updated" . $link->error;
                    }

                    while($row3 = $result3->fetch_assoc())
                    {
                        if($row3["factory_worker_amount"] >= 0)
                        {
                            $sql7 = "UPDATE companies SET company_worker_amount = company_worker_amount - '" . $row3["factory_worker_amount"] . "' WHERE company_id = '" . $selectedFacOwner . "' and player_id = '" . $playerCode . "';";

                            echo"Worker amount changed" . $row3["factory_worker_amount"];

                            if($result7 = $link->query($sql7))
                            {
                                echo "Successfully updated amount of workers from company";
                            }
                            else
                            {
                                echo "Amount of workers from company not updated" . $link->error;
                            }
                        }
                    }
                    echo "Factory selected: " . $selectedFac . "You have purchased a factory and your money is now: " . $row2["company_money"] . " The owner of the factory was: " . $selectedFacOwner;
                }
                else
                {
                    echo "You dont have enough money";
                }
            }
        }
    }
}
else
{
    echo "This has no price" . $row;
}

$link->close();

?>