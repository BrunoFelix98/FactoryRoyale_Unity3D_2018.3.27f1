<?php

include "Server.php";

$company = array();

$playerCode = $_POST["player_code"];

$companyID = $_GET["company_id"];
$companyMoney = $_GET["company_money"];
$companyWorkerAmount = $_GET["company_worker_amount"];
$companyAmountOfFactoriesOwned = $_GET["company_amount_of_factories_owned"];

$sql = "SELECT * FROM companies WHERE player_id = '" . $playerCode . "';";

$result = $link->query($sql);

if($result->num_rows > 0)
{

    while($row = $result->fetch_assoc())
    {
        $company[] = $row;
    }
}
else
{
    echo "Something went wrong with: " . $company;
}

echo json_encode($company);

$link->close();

?>