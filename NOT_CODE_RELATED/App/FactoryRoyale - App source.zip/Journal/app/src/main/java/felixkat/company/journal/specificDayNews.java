package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.CaseMap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class specificDayNews extends AppCompatActivity {

    private Button MAButton;
    private Button BtBButton;
    private Button UPButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific_day_news);

        Intent intent = getIntent();
        NewsCardView newsView = intent.getParcelableExtra("Example Item");

        String line1 = newsView.getText1();

        TextView title = findViewById(R.id.specNewsTitle);
        if(newsView.getText1().equals("Today") || newsView.getText1().equals("Yesterday")) {
            title.setText(line1 + "'s news");
        }
        else{
            title.setText(line1 + " "+"news");
        }

        //Main article button event listener
        MAButton = (Button) findViewById(R.id.MA);
        MAButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainArticle();
            }
        });

        //Bot to bot article button event listener
        BtBButton = (Button) findViewById(R.id.BtB);
        BtBButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBottoBot();
            }
        });

        //Upgrade article button event listener
        UPButton = (Button) findViewById(R.id.UP);
        UPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openUpArticle();
            }
        });
    }

    //Main article opener function
    public void openMainArticle()
    {
        Intent openMainArticle = new Intent(this, main_article.class);
        startActivity(openMainArticle);
    }

    //Bot to bot article opener function
    public void openBottoBot()
    {
        Intent openBottoBot = new Intent(this, bots_article.class);
        startActivity(openBottoBot);
    }

    //Upgrade article opener function
    public void openUpArticle()
    {
        Intent openUpArticle = new Intent(this, upgrade_article.class);
        startActivity(openUpArticle);
    }

}
