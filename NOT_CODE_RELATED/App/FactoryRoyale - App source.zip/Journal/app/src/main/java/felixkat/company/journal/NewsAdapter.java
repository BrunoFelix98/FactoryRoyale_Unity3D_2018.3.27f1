package felixkat.company.journal;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {

    private ArrayList<NewsCardView> mNewsList;

    private OnitemClickListener nListener;

    public interface OnitemClickListener
    {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnitemClickListener listener)
    {
        nListener = listener;
    }

    public static class NewsViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView NewsImage;
        public TextView Text1;
        public TextView Text2;

        public NewsViewHolder(View itemView, final OnitemClickListener listener)
        {
            super(itemView);
            NewsImage = itemView.findViewById(R.id.Img);
            Text1 = itemView.findViewById(R.id.Txt1);
            Text2 = itemView.findViewById(R.id.Txt2);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null)
                    {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                        {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public NewsAdapter(ArrayList<NewsCardView> newsCardViewList )
    {
        mNewsList = newsCardViewList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        NewsViewHolder nvh = new NewsViewHolder(v, nListener);
        return nvh;
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsCardView currentNews = mNewsList.get(position);

        holder.NewsImage.setImageResource(currentNews.getImage());
        holder.Text1.setText(currentNews.getText1());
        holder.Text2.setText(currentNews.getText2());
    }

    @Override
    public int getItemCount() {
        return mNewsList.size();
    }
}
