package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class StartOfNews extends AppCompatActivity {

    private TextView factory1;
    private TextView factory2;
    private TextView factory3;
    private TextView factory4;
    private TextView factory5;
    private TextView factory6;
    private TextView factory7;
    private TextView factory8;
    private TextView factory9;
    private TextView factory10;
    private TextView factory11;
    private TextView factory12;
    private TextView factory13;
    private TextView factory14;
    private TextView factory15;
    private TextView factory16;
    private TextView factory17;
    private TextView factory18;
    private TextView factory19;
    private TextView factory20;
    private TextView factory21;
    private TextView factory22;
    private TextView factory23;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_of_news);

        factory1 = findViewById(R.id.factory1);
        factory2 = findViewById(R.id.factory2);
        factory3 = findViewById(R.id.factory3);
        factory4 = findViewById(R.id.factory4);
        factory5 = findViewById(R.id.factory5);
        factory6 = findViewById(R.id.factory6);
        factory7 = findViewById(R.id.factory7);
        factory8 = findViewById(R.id.factory8);
        factory9 = findViewById(R.id.factory9);
        factory10 = findViewById(R.id.factory10);
        factory11 = findViewById(R.id.factory11);
        factory12 = findViewById(R.id.factory12);
        factory13 = findViewById(R.id.factory13);
        factory14 = findViewById(R.id.factory14);
        factory15 = findViewById(R.id.factory15);
        factory16 = findViewById(R.id.factory16);
        factory17 = findViewById(R.id.factory17);
        factory18 = findViewById(R.id.factory18);
        factory19 = findViewById(R.id.factory19);
        factory20 = findViewById(R.id.factory20);
        factory21 = findViewById(R.id.factory21);
        factory22 = findViewById(R.id.factory22);
        factory23 = findViewById(R.id.factory23);


        Intent intent = getIntent();
        NewsCardView newsView = intent.getParcelableExtra("Example Item");

        String line1 = newsView.getText1();

        TextView title = findViewById(R.id.startOfNews);
        if(newsView.getText1().equals("Today") || newsView.getText1().equals("Yesterday")) {
            title.setText(line1 + "'s news");
        }
        else{
            title.setText(line1 + " "+"news");
        }

        factory1.setText("1. Poirot Inc.");
    }
}
