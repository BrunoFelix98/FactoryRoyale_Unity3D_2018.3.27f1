package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class upgrade_article extends AppCompatActivity {

    public Button UPCTBtn;
    public TextView UPTitle;
    public TextView UPText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upgrade_article);

        UPCTBtn = findViewById(R.id.UPCTBtn);
        UPCTBtn.setVisibility(View.INVISIBLE);
        UPTitle = findViewById(R.id.UPTitle1);
        UPText = findViewById(R.id.UPText);

        UPTitle.setText("Poirot Inc. Invests in security!");
        UPText.setText("Today Poirot Inc. has hired staff to perform security shifts inside of the factory. The workers seem a bit happier since they are more secure!");

        /*UPCTBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UPChangeTitle();
            }
        });*/
    }

    /*public void UPChangeTitle()
    {
        Random rand = new Random();
        int Number = rand.nextInt(3);

        if(Number == 0)
        {
            UPTitle.setText("Bot name" + "Has advanced in tge line of Efficiency!");
            UPText.setText("Better efficiency at work has been achieved at" + "Bot factory name" + "! Hopefully this wont cause the workers too much work overload!");
        }

        if(Number == 1)
        {
            UPTitle.setText("Bot name" + "has advanced in the line of Security!");
            UPText.setText("Better security has arrived at " + "Bot factory name" + "! The workers feel safer now!");
        }

        if(Number == 2)
        {
            UPTitle.setText("Bot name" + "has advanced in the line of Worker Conditions!");
            UPText.setText("Better worker conditions hit" + "Player factory name" + "! This is said to be amazing, the player really cares about his workers!");
        }
    }*/
}
