package felixkat.company.journal;

import android.os.Parcel;
import android.os.Parcelable;

public class StatsCardView implements Parcelable {

    private int StatsImage;
    private String Text1;
    private String Text2;

    public StatsCardView(int statsImage, String text1, String text2)
    {
        StatsImage = statsImage;
        Text1 = text1;
        Text2 = text2;
    }

    protected StatsCardView(Parcel in)
    {
        StatsImage = in.readInt();
        Text1 = in.readString();
        Text2 = in.readString();
    }

    public static final Creator<StatsCardView> CREATOR = new Creator<StatsCardView>() {
        @Override
        public StatsCardView createFromParcel(Parcel in) {
            return  new StatsCardView(in);
        }

        @Override
        public StatsCardView[] newArray(int size) {
            return new StatsCardView[size];
        }
    };

    public int getImage()
    {
        return StatsImage;
    }

    public String getText1()
    {
        return Text1;
    }

    public String getText2()
    {
        return Text2;
    }

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(StatsImage);
        dest.writeString(Text1);
        dest.writeString(Text2);
    }
}