package felixkat.company.journal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.widget.ImageView;

public class NewsCardView implements Parcelable {

    private int NewsImage;
    private String Text1;
    private String Text2;

    public NewsCardView(int newsImage, String text1, String text2)
    {
        NewsImage = newsImage;
        Text1 = text1;
        Text2 = text2;
    }

    protected NewsCardView(Parcel in)
    {
        NewsImage = in.readInt();
        Text1 = in.readString();
        Text2 = in.readString();
    }

    public static final Creator<NewsCardView> CREATOR = new Creator<NewsCardView>() {
        @Override
        public NewsCardView createFromParcel(Parcel in) {
            return  new NewsCardView(in);
        }

        @Override
        public NewsCardView[] newArray(int size) {
            return new NewsCardView[size];
        }
    };

    public int getImage()
    {
        return NewsImage;
    }

    public String getText1()
    {
        return Text1;
    }

    public String getText2()
    {
        return Text2;
    }


    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(NewsImage);
        dest.writeString(Text1);
        dest.writeString(Text2);
    }
}
