package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class bots_article extends AppCompatActivity {

    public Button BtBCTBtn;
    public TextView BtBTitle;
    public TextView BtBText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bots_article);

        BtBCTBtn = findViewById(R.id.CTbtnB);
        BtBCTBtn.setVisibility(View.INVISIBLE);
        BtBTitle = findViewById(R.id.BtBTitle1);
        BtBText = findViewById(R.id.BtBText1);

        BtBTitle.setText("Cici Inc. improved their worker conditions!");
        BtBText.setText("With better worker conditions Sciniawa's workers can now enjoy a better life at work, leaving them more satisfied and less likely to leave the factory!");

        /*BtBCTBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BtBChangeTitle();
            }
        });*/
    }

    /*public void BtBChangeTitle()
    {
        Random rand = new Random();
        int Number = rand.nextInt(2);

        if(Number == 0)
        {
            BtBTitle.setText("Bot factory has been sabotaged!");
            BtBText.setText("Today the " + "factory name" + "has been sabotaged and will be less efficient! Some people might leave the factory due to bad security!");
        }

        if(Number == 1)
        {
            BtBTitle.setText("Bot has failed to sabotage" + "bot name" + "'s factory!");
            BtBText.setText("Today the Bot name has failed to sabotage" + "Factory name" + "belonging to" + "Bot company name" + ". Some people might leave the Player's factory due to how untrustworthy their boss is!");
        }
    }*/
}
