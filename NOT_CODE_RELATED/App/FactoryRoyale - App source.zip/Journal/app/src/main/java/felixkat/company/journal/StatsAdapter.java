package felixkat.company.journal;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StatsAdapter extends RecyclerView.Adapter<StatsAdapter.StatsViewHolder> {

    private ArrayList<StatsCardView> mStatsList;

    private StatsAdapter.OnitemClickListener nListener;

    public interface OnitemClickListener
    {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(StatsAdapter.OnitemClickListener listener)
    {
        nListener = listener;
    }

    public static class StatsViewHolder extends RecyclerView.ViewHolder
    {
        public ImageView StatsImage;
        public TextView Text1;
        public TextView Text2;

        public StatsViewHolder(View itemView, final StatsAdapter.OnitemClickListener listener)
        {
            super(itemView);
            StatsImage = itemView.findViewById(R.id.Img);
            Text1 = itemView.findViewById(R.id.Txt1);
            Text2 = itemView.findViewById(R.id.Txt2);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null)
                    {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION)
                        {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public StatsAdapter(ArrayList<StatsCardView> statsCardViewList )
    {
        mStatsList = statsCardViewList;
    }

    @NonNull
    @Override
    public StatsAdapter.StatsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        StatsAdapter.StatsViewHolder svh = new StatsAdapter.StatsViewHolder(v, nListener);
        return svh;
    }

    @Override
    public void onBindViewHolder(@NonNull StatsAdapter.StatsViewHolder holder, int position) {
        StatsCardView currentFactory = mStatsList.get(position);

        holder.StatsImage.setImageResource(currentFactory.getImage());
        holder.Text1.setText(currentFactory.getText1());
        holder.Text2.setText(currentFactory.getText2());
    }

    @Override
    public int getItemCount() {
        return mStatsList.size();
    }
}
