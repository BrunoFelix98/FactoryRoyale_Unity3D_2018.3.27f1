package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.View;
import android.view.textclassifier.TextLinks;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParsePosition;

public class specificFactory extends AppCompatActivity {

    private RequestQueue mQueue;

    public ImageView Happiness;
    public ImageView Efficiency;
    public ImageView Security;
    public ImageView Money;

    public String line1;
    public String Pcode;
    private String ip = "localhost";

    public TextView workerAmount;
    public TextView efficiency;
    public TextView security;
    public TextView money;

    public TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific_factory);

        mQueue = Volley.newRequestQueue(this);

        Happiness = findViewById(R.id.happiness);
        Efficiency = findViewById(R.id.efficiency);
        Security = findViewById(R.id.security);
        Money = findViewById(R.id.moneyPs);

        workerAmount = findViewById(R.id.workerAmountTxt);
        efficiency = findViewById(R.id.efficiencyTxt);
        security = findViewById(R.id.securityTxt);
        money = findViewById(R.id.moneyPsTxt);

        Efficiency.setImageResource(R.drawable.efficiency_icon);
        Security.setImageResource(R.drawable.security_icon);
        Money.setImageResource(R.drawable.money);

        title = findViewById(R.id.specFacTitle);

        Intent intent = getIntent();
        StatsCardView statsView = intent.getParcelableExtra("Example Item");
        Pcode = getIntent().getStringExtra("player_code");

        line1 = statsView.getText1();

        TextView title = findViewById(R.id.specFacTitle);
        title.setText(line1 + "'s stats");

        getFactory();
    }

    public void getFactory()
    {
        String url = "http://"+ ip +"/phpServer/playerOwnedFacsApp.php?factory_owner_id=1&player_id=" + Pcode;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("Factory");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject factory = jsonArray.getJSONObject(i);

                                if(factory.getString("factoryName").equals(line1))
                                {
                                    double jhappiness = factory.getInt("factory_worker_happiness");
                                    int jworkerAmount = factory.getInt("factory_worker_amount");
                                    int jsecurityLevel = factory.getInt("factory_security_level");
                                    int jefficiencyLevel = factory.getInt("factory_efficiency_level");
                                    int jmoneyPs = factory.getInt("factory_money_per_second");

                                    if (jhappiness >= 0 && jhappiness <= 20) {
                                        Happiness.setImageResource(R.drawable.angry_worker);
                                    } else if (jhappiness >= 20 && jhappiness <= 40) {
                                        Happiness.setImageResource(R.drawable.slightly_angry_worker);
                                    } else if (jhappiness >= 40 && jhappiness <= 60) {
                                        Happiness.setImageResource(R.drawable.neutral_worker);
                                    } else if (jhappiness >= 60 && jhappiness <= 80) {
                                        Happiness.setImageResource(R.drawable.slightly_happy_worker);
                                    } else if (jhappiness >= 80 && jhappiness <= 100) {
                                        Happiness.setImageResource(R.drawable.happy_worker);
                                    }

                                    workerAmount.setText(String.valueOf(jworkerAmount));
                                    efficiency.setText(String.valueOf(jefficiencyLevel));
                                    security.setText(String.valueOf(jsecurityLevel));
                                    money.setText(jmoneyPs + "/s");

                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
        mQueue.add(request);
    }
}

