package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CardViewNewspaper extends AppCompatActivity {

    private ArrayList<NewsCardView> NewList;

    private RecyclerView NewsRV;
    private NewsAdapter NrvAdapter;
    private RecyclerView.LayoutManager NrvLayoutManager;

    private TextView compName;
    private String compNameS;

    private Button Insert;
    private Button Remove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view_newspaper);

        compNameS = getIntent().getStringExtra("company_name");

        createNewList();
        createNewRV();

        compName = (TextView) findViewById(R.id.compName);
        compName.setText(compNameS);

        Insert = findViewById(R.id.addFactory);
        Remove = findViewById(R.id.removeFactory);

        Insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = NewList.size();
                insertNews(position);
            }
        });

        Insert.setVisibility(View.INVISIBLE);

        Remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openStats();
            }
        });

    }

    public void insertNews(int position) {
        NewList.add(position, (new NewsCardView((R.drawable.news_button), NewList.size() + " " + "Days ago", "News")));
        NrvAdapter.notifyItemInserted(position);
    }

    public void openStats()
    {
        Intent openStatistics = new Intent(CardViewNewspaper.this, StatsCardView.class);
        startActivity(openStatistics);
    }

    public void removeNews(int position) {
        if (NewList.size() >= 1) {
            NewList.remove(position);
            NrvAdapter.notifyItemRemoved(position);
        }
    }

    public void createNewList()
    {
        NewList = new ArrayList<>();
        NewList.add(new NewsCardView((R.drawable.news_button), "Today", "News"));
        NewList.add(new NewsCardView((R.drawable.news_button), "Yesterday", "News"));
    }

    public void createNewRV()
    {
        NewsRV = findViewById(R.id.StatsRV);
        NrvLayoutManager = new LinearLayoutManager(this);
        NrvAdapter = new NewsAdapter(NewList);

        NewsRV.setLayoutManager(NrvLayoutManager);
        NewsRV.setAdapter(NrvAdapter);

        NrvAdapter.setOnItemClickListener(new NewsAdapter.OnitemClickListener() {
            @Override
            public void onItemClick(int position) {

                if(NewList.get(position).equals(NewList.get(NewList.size()-1)))
                {
                    Intent intent = new Intent(CardViewNewspaper.this, StartOfNews.class);
                    intent.putExtra("Example Item", NewList.get(position));

                    startActivity(intent);
                }
                else
                {
                    Intent intent = new Intent(CardViewNewspaper.this, specificDayNews.class);
                    intent.putExtra("Example Item", NewList.get(position));

                    startActivity(intent);
                }
            }
        });
    }
}
