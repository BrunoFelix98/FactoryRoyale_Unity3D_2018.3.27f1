package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class CardViewStatistics extends AppCompatActivity {

    private RequestQueue mQueue2;

    private ArrayList<StatsCardView> NewList;
    public String facName;
    public String Pcode;
    private String ip = "localhost";

    private RecyclerView StatsRV;
    private StatsAdapter SrvAdapter;
    private RecyclerView.LayoutManager SrvLayoutManager;

    private Button Insert;
    private Button Remove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view_statistics);

        mQueue2 = Volley.newRequestQueue(this);
        NewList = new ArrayList<>();
        getFactory();
        createNewRV();

        Pcode = getIntent().getStringExtra("player_code");

        Insert = findViewById(R.id.addFactory);
        Remove = findViewById(R.id.removeFactory);

        Insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = NewList.size();
                insertFactory(position);
            }
        });

        Insert.setVisibility(View.INVISIBLE);

        Remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = NewList.size() - 1;
                removeFactory(position);
            }
        });

        Remove.setVisibility(View.INVISIBLE);


    }

    public void insertFactory(int position) {
        NewList.add(position, (new StatsCardView((R.drawable.factory64), NewList.size() + " " + "Factory", " ")));
        SrvAdapter.notifyItemInserted(position);
    }

    public void removeFactory(int position) {
        if (NewList.size() >= 1) {
            NewList.remove(position);
            SrvAdapter.notifyItemRemoved(position);
        }
    }

    public void getFactory()
    {
        String url = "http://"+ ip +"/FactoryRoyale/getFactoryApp.php?factory_owner_id=1&player_id=" + Pcode;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            JSONArray jsonArray = response.getJSONArray("Names");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject Name = jsonArray.getJSONObject(i);

                                facName = Name.getString("factory_name");

                                NewList.add(i, (new StatsCardView((R.drawable.factory64), facName, " ")));
                                SrvAdapter.notifyItemInserted(i);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        mQueue2.add(request);
    }

    public void createNewRV() {
        StatsRV = findViewById(R.id.StatsRV);
        SrvLayoutManager = new LinearLayoutManager(this);
        SrvAdapter = new StatsAdapter(NewList);

        StatsRV.setLayoutManager(SrvLayoutManager);
        StatsRV.setAdapter(SrvAdapter);

        SrvAdapter.setOnItemClickListener(new StatsAdapter.OnitemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(CardViewStatistics.this, specificFactory.class);
                intent.putExtra("Example Item", NewList.get(position));

                startActivity(intent);
            }
        });
    }
}
