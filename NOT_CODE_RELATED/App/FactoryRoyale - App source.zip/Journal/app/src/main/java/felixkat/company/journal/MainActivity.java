package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.StringPrepParseException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private RequestQueue mQueue2;

    private Button Cbutton;
    private EditText CText;

    private String code;
    private String ip = "localhost";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQueue2 = Volley.newRequestQueue(this);

        CText = (EditText) findViewById(R.id.codeText);

        //Newspaper button event listener
        Cbutton = (Button) findViewById(R.id.submitCode);
        Cbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                code = CText.getText().toString();
                getPlayer();
            }
        });
    }
    //Newspaper opener function
    public void openNewspaper(String compname, String pCode)
    {
        Intent openNewspaper = new Intent(this, CardViewNewspaper.class);
        openNewspaper.putExtra("company_name", compname);
        openNewspaper.putExtra("player_code", pCode);
        startActivity(openNewspaper);
    }

    public void getPlayer()
    {
        String url = "http://"+ ip +"/FactoryRoyale/getPlayerCodeApp.php?player_code=" + code;
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            String compName = response;
                            if(compName.equals("Player nonexistent: " + code))
                            {
                                Toast.makeText(MainActivity.this, "Player nonexistent", Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                openNewspaper(compName, code);
                            }
                        }
                        catch(NullPointerException ignored) {
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
        mQueue2.add(request);
    }
}
