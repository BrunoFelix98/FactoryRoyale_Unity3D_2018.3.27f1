package felixkat.company.journal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class main_article extends AppCompatActivity {

    public Button CTbtn;
    public TextView title;
    public TextView MAText;
    public ImageView MASC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_article);

        CTbtn = findViewById(R.id.CTbtn);
        CTbtn.setVisibility(View.INVISIBLE);
        title = findViewById(R.id.MATitle1);
        MAText = findViewById(R.id.MAText);
        MASC = findViewById(R.id.MAImage1);

        title.setText("Poirot Inc. gets caught!");
        MAText.setText("Today, Poirot Inc. attempted to sabotage Milicz's factory, owned by CZ Inc. Some people from Poirot Inc. were not happy and left their workspaces!");
        MASC.setImageResource(R.drawable.loss_screen_shot);

        /*CTbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeTitle();
            }
        });*/
    }

    /*public void changeTitle()
    {
        Random rand = new Random();
        int Number = rand.nextInt(6);

        if(Number == 0)
        {
            title.setText("Player factory has been sabotaged!");
            MAText.setText("Today the " + "factory name" + "has been sabotaged and will be less efficient! Some people might leave the factory due to bad security!");
        }

        if(Number == 1)
        {
            title.setText("Player has failed to sabotage" + "bot name" + "'s factory!");
            MAText.setText("Today the player has failed to sabotage" + "Factory name" + "belonging to" + "Bot company name" + ". Some people might leave the Player's factory due to how untrustworthy their boss is!");
        }

        if(Number == 2)
        {
            title.setText("Player has advanced in the line of Security!");
            MAText.setText("Better security has arrived at " + "Player factory name" + "! The workers feel safer now!");
        }

        if(Number == 3)
        {
            title.setText("Player has advanced in the line of Efficiency!");
            MAText.setText("Better efficiency at work has been achieved at" + "Player factory name" + "! Hopefully this wont cause the workers too much work overload!");
        }

        if(Number == 4)
        {
            title.setText("Player has advanced in the line of Worker Conditions!");
            MAText.setText("Better worker conditions hit" + "Player factory name" + "! This is said to be amazing, the player really cares about his workers!");
        }

        if(Number == 5)
        {
            title.setText("Bot name" + "tried to sabotage the Player");
            MAText.setText("Bot name" + "tried to sabotage the Player today, they failed due to the superior security in the Player's factory! This will surely make a dent inside of" + "Bot's name" + "'s factories!");
        }
    }*/
}
